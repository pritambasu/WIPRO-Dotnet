
select * from employee where LEN(SALARY) > 3