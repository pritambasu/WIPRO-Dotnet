Insert into employee
(emp_id , fname , minit , lname , job_id , job_lvl , pub_id , hire_date)
Values
('L-B3147P' , 'Ramesh' , 's' , 'Tendulkar' , '88', '55' , '1389' , '1990-12-24 00:00:00.000')